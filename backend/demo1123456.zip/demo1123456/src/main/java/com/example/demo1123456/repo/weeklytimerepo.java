package com.example.demo1123456.repo;

import com.example.demo1123456.entity.weeklytime;
import org.springframework.data.repository.CrudRepository;

public interface weeklytimerepo extends CrudRepository<weeklytime, Long> {}
