package com.example.demo1123456;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class demoapplicationtime {

    public static void main(String[] args) {
        SpringApplication.run(demoapplicationtime.class, args);
    }
}