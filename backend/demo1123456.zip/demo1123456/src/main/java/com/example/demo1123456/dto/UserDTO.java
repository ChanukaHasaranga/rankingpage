package com.example.demo1123456.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data

public class UserDTO {

    public int id;
    public String name;
    public String address;
    public int count;
//private int id;
//    private String name;
//    private String address;
//    private int count;
//    private int year;
//    private int month;
//    private int day;
//    private String newDate;


}
