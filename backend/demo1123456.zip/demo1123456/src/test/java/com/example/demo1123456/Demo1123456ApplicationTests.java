package com.example.demo1123456;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo1123456ApplicationTests {

    @Test
    void contextLoads() {
    }

}
